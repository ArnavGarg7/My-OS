---
name: Kinetic Obsidian
colors:
  surface: '#111316'
  surface-dim: '#111316'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e11'
  surface-container-low: '#1a1c1f'
  surface-container: '#1e2023'
  surface-container-high: '#282a2d'
  surface-container-highest: '#333538'
  on-surface: '#e2e2e6'
  on-surface-variant: '#e0c0b1'
  inverse-surface: '#e2e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#a78b7d'
  outline-variant: '#584236'
  surface-tint: '#ffb68e'
  primary: '#ffb68e'
  on-primary: '#542200'
  primary-container: '#ff7a1a'
  on-primary-container: '#5e2700'
  inverse-primary: '#9c4500'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#08b77f'
  on-tertiary-container: '#00402a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb68e'
  on-primary-fixed: '#331200'
  on-primary-fixed-variant: '#773300'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#111316'
  on-background: '#e2e2e6'
  surface-variant: '#333538'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.04em
  caption-micro:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  shell-rail: 4.5rem
  shell-dock-h: 4rem
  sheet-max-w: 42rem
---

## Brand & Style

The design system embodies the philosophy of a personal operating system: calm, cerebral, ultra-refined, and strictly intentional. It functions as an extension of the user's executive cognitive function rather than a noisy workspace or extractive feed.

### Core Tenets
- **Cerebral Serenity:** Visual quietude over decoration. Every visible element must earn its pixel real estate through clear utility or ambient situational awareness.
- **Hardware-Grade Precision:** Tactile, dense, machined, and engineered. Surfaces evoke milled anodized aluminum, obsidian glass, and optical coatings.
- **Dynamic Presence:** The active focus state glows with warm, luminous energy against a void of deep graphite and obsidian, signaling active agency and deliberate human intent.

### Design Movement & Flavor
The visual style fuses **Neo-Minimalism** with **Machined Skeuomorphism** and **Optical Depth**:
- **Canvas:** Ultra-deep, non-pure black graphite layers that establish physical grounding without harsh OLED black cutoffs.
- **Boundaries:** Sub-pixel hairline borders (`rgba(255, 255, 255, 0.08)`) and precision-milled structural outlines, ditching bulky drop shadows.
- **Accents:** Molten amber/cadmium highlights signifying kinetic energy, balanced by surgical monospace indicators for state, time, and system metrics.

## Colors

The palette operates on physical canvas logic, relying on stepped obsidian and graphite values paired with calibrated luminous semaphores.

### Surface Tiers
- **Void (Base Canvas):** `#0C0D0E` — Deep background for the global desktop viewport and sheet backdrops.
- **Base (Substrate):** `#141618` — Primary panel, command deck, and workspace canvas.
- **Surface Elevation 1 (Card / Column):** `#1A1D20` — Floating containers, sidebar panels, and list tracks.
- **Surface Elevation 2 (Raised / Hover):** `#22262B` — Active hover states, nested cards, and button backgrounds.
- **Surface Elevation 3 (Popover / Modal):** `#2A2F35` — Command palettes (`Cmd+K`), contextual menus, and tooltips.

### Accent & Semantics
- **Primary Kinetic Accent (`#FF7A1A`):** Pure intentionality. Reserved for current focus mode, active command highlights, interactive toggles in active states, and critical action triggers. Secondary amber ramp (`#F59E0B`, `#FBBF24`) provides warm fallback luminance.
- **Sync & Ambient Intelligence (`#38BDF8`):** Arctic blue for live cloud sync, ambient AI processing, and real-time network states.
- **Verified / Resolved (`#10B981`):** Sage/emerald for completed workflows, healthy telemetry, and verified data states.
- **Urgent Attention (`#F43F5E`):** Soft rose-crimson for blocking errors, strict deadlines, and system interruptions.

### Structural Alpha Borders
- **Sub-Border Subtle:** `rgba(255, 255, 255, 0.06)` for internal list dividers and nested grid separators.
- **Sub-Border Distinct:** `rgba(255, 255, 255, 0.12)` for card perimeters, modal bounding boxes, and dock edges.
- **Active Glow Stroke:** `rgba(255, 122, 26, 0.35)` paired with a soft 12px outer diffusion for focused items.

## Typography

The type hierarchy balances rationalist neo-grotesque clarity (`Inter`) with mechanical precision (`JetBrains Mono`). 

### Dual-Engine Typography System
- **Prose & Interaction:** `Inter` handles all primary tasks, natural-language titles, navigational anchors, and body descriptions. Dense optical metrics and micro tracking adjustments ensure high legibility at 13px and 14px.
- **Machine State & Telemetry:** `JetBrains Mono` handles non-prose metadata: keyboard shortcuts (`⌘K`), system state tokens, timestamps, elapsed timers, latency telemetry, and numeric progress metrics.

### Typographic Discipline
- Never set headings in pure white (`#FFFFFF`). Use an off-white optical tint (`#EDEDED`) to reduce retinal fatigue.
- Secondary copy uses muted cool slate (`#949DA6`).
- All monospace label badges must be uppercase or strict mathematical expressions.

## Layout & Spacing

The layout is built upon an 8-point base grid with a 4-point micro-step for tight toolbars and data-dense listings.

### Structure & Shell Architecture
- **Desktop (>=1024px):**
  - **Persistent Shell Rail (72px):** Fixed left navigation strip harboring identity, workspace switcher, and vertical status nodes.
  - **Fluid Work Desk:** Central command space with a dynamic fluid layout constrained to a maximum reading lane of `1280px`.
  - **Inspector Drawer (Collapsible):** `340px` contextual sidebar docked to the right edge.
- **Tablet (768px – 1023px):**
  - Left rail collapses to an auto-hide edge trigger.
  - Content shifts to an adaptive 8-column layout with 16px gutters and 24px margins.
- **Mobile (<768px):**
  - Rail and sidebars collapse into a **Thumb-Friendly Bottom Dock (64px)**.
  - Quick-capture triggers elevate to a floating kinetic action bubble above the dock.
  - Detail views transform into full-height or snap-to-half fluid bottom sheets.

### Density Tiers
- **Comfort:** `16px` padding inside cards, `12px` gaps between sibling components (focused reading, markdown editing).
- **Compact (OS Default):** `8px` padding inside interactive rows, `4px` margins between list items (command palettes, log feeds, active sprint blocks).

## Elevation & Depth

Visual hierarchy does not rely on heavy drop shadows or bright planes. It utilizes **machined physical elevation tiers** combining stepped ambient illumination, optical edge reflection, and frosted backing.

### Tiers of Depth
- **Level 0 (Deep Ground):** Canvas background (`#0C0D0E`). Absorbs focus. No shadow, no outline.
- **Level 1 (Substrate Panel):** `#141618` framed by a 1px inner edge `inset 0 1px 0 0 rgba(255, 255, 255, 0.05)` and an exterior border of `rgba(255, 255, 255, 0.07)`.
- **Level 2 (Interactive Floating Unit):** `#1A1D20` with a dual shadow:
  - Ambient base: `0 8px 24px -4px rgba(0, 0, 0, 0.45)`
  - Edge bounce: `0 1px 2px 0 rgba(0, 0, 0, 0.3)`
  - Rim highlight: `1px solid rgba(255, 255, 255, 0.09)`
- **Level 3 (Command Overlay & Modals):** Translucent obsidian substrate `#141618EB` layered with `backdrop-filter: blur(20px) saturate(160%)`.
  - Outer projection: `0 24px 48px -12px rgba(0, 0, 0, 0.75)`
  - Perimeter highlight: `1px solid rgba(255, 255, 255, 0.14)`

### The Kinetic Active Aura
Focused windows or cards in active focus mode receive a localized, low-spread ambient glow:
- `box-shadow: 0 0 0 1px #FF7A1A, 0 0 20px -4px rgba(255, 122, 26, 0.25)`

## Shapes

The shape system adopts a disciplined, machined corner geometry (Level 1: Soft / Precision-Engineered). Rounding is subtle and deliberate, communicating structured hardware rather than bubbly toy-like interfaces.

### Radius Token Scale
- **Micro Elements (4px / `0.25rem`):** Checkboxes, code badges, keyboard shortcut chips (`Kbd`), internal scroll throttles.
- **Controls & Form Inputs (6px / `0.375rem`):** Buttons, text entry boxes, dropdown toggles, list-item selection bounds.
- **Cards & Panes (8px / `0.5rem`):** Dashboard tiles, workflow cards, timeline blocks.
- **System Containers & Modals (12px / `0.75rem`):** Command palette modals, sheet containers, floating thumb-dock.
- **Full Pill (`9999px`):** Reserved exclusively for live status pill indicators, human presence badges, and active state toggles.

## Components

### 1. Buttons & Triggers
- **Primary Kinetic:** Background `#FF7A1A`, text `#0C0D0E` (bold 600 weight), internal top specular line `inset 0 1px 0 rgba(255,255,255,0.25)`. Hover elevates brightness to `#FF8D3B`. Active click scales to `0.985`.
- **Subtle / Ghost:** Background `transparent`, text `#EDEDED`, border `1px solid rgba(255, 255, 255, 0.08)`. Hover fills to `#1A1D20`.
- **Keyboard Affordance:** Buttons display trailing monospace shortcut indicators styled with low-contrast background pill boxes (`#22262B`, `11px JetBrains Mono`).

### 2. Command Palette (`Cmd+K`)
- Center-locked modal with `560px` fixed width on desktop; snaps into a full bottom sheet on mobile.
- Top input is unbordered, 18px font size, featuring an obsidian dark background and a flickering kinetic cursor.
- Results list grouped with uppercase monospace section headers (`label-code-sm`).
- Keyboard active row receives `#22262B` background with a left 2px vertical indicator bar in primary kinetic amber.

### 3. Quick Capture Bar
- Fixed dock unit featuring an omni-input field capable of accepting natural language time stamps, tags, and semantic priorities.
- Employs live tag parsing: typing `#` turns the phrase into a scoped pill token; typing `@` opens immediate person/agent assignments.

### 4. Dense List Items & Micro-Actions
- Single-line height calibrated to `40px` for optimal informational density.
- Trailing micro-actions (Pin, Complete, Defer, More) stay hidden at `opacity: 0` until row hover or focus, avoiding visual chatter.
- Monospace metadata (timestamps, elapsed trackers) pinned to strict right-aligned tabular numbers (`font-variant-numeric: tabular-nums`).

### 5. Tactical Switches & Checkboxes
- **Checkbox:** 16x16px square with 4px border-radius. Inactive: `border: 1px solid rgba(255,255,255,0.2)`. Checked: `#10B981` with an emerald micro-glow and sharp white check icon.
- **Machined Toggle Switch:** 36x20px capsule track. Thumb is a 16x16px brushed silver disc (`#E2E8F0`). In active state, the track transitions to `#FF7A1A` with a spring-curve slide.

### 6. State Indicators & Badges
- Encapsulated within `label-code-sm` monospace typography.
- Built with a 6px status bead alongside text. The bead features an optional radial pulse ring for active states (e.g., syncing or audio recording).
- Tone matches semantic intent: Sage for verified/synced, Amber for pending queue, Arctic Blue for ambient processing, Soft Rose for urgent interventions.